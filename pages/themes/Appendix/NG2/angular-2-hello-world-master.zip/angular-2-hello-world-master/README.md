# angular-2-hello-world
Hello world with Angular 2. This repo servers a simple example for an Angular 2 app using ES6 and Babel.


# Dependencies

- [Node.js](https://nodejs.org/en/)
- [Gulp.js](http://gulpjs.com/)

# Quick Start

Clone this repository:

```bash
git clone git@github.com:agconti/angular-2-hello-world.git
```

Install dependencies:

```bash
npm install
```

Run the developement server

```bash
gulp
```
